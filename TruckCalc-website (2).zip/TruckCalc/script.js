const $ = (id) => document.getElementById(id);
const number = (id) => Math.max(0, Number($(id).value) || 0);
const fmt = (value, digits = 2) => value.toLocaleString('en-US', {minimumFractionDigits: digits, maximumFractionDigits: digits});

function updateDistance() {
  const value = number('miles');
  $('kmResult').innerHTML = `${fmt(value * 1.609344)} <i>km</i>`;
}
function updateLiters() {
  $('literResult').innerHTML = `${fmt(number('gallons') * 3.785411784)} <i>L</i>`;
}
function updateFuel() {
  const distance = number('distanceFuel');
  const mpg = Number($('mpg').value);
  const price = number('price');
  const total = mpg > 0 ? (distance / mpg) * price : 0;
  $('fuelResult').textContent = `$${fmt(total)}`;
}
function updateTotal() {
  $('totalResult').innerHTML = `${fmt(number('leg1') + number('leg2'))} <i>mile</i>`;
}
['miles'].forEach(id => $(id).addEventListener('input', updateDistance));
['gallons'].forEach(id => $(id).addEventListener('input', updateLiters));
['distanceFuel','mpg','price'].forEach(id => $(id).addEventListener('input', updateFuel));
['leg1','leg2'].forEach(id => $(id).addEventListener('input', updateTotal));

let reverseDistance = false;
$('swapDistance').addEventListener('click', () => {
  const input = $('miles');
  const value = number('miles');
  if (!reverseDistance) {
    input.value = value * 1.609344;
    input.previousElementSibling;
    input.parentElement.querySelector('span').textContent = 'km';
    $('kmResult').innerHTML = `${fmt(value)} <i>mile</i>`;
    $('swapDistance').textContent = 'Miledan kilometrga hisoblash ↗';
    input.closest('.tool-card').querySelector('label').textContent = 'Kilometr (km)';
  } else {
    input.value = value / 1.609344;
    input.parentElement.querySelector('span').textContent = 'mi';
    updateDistance();
    $('swapDistance').textContent = 'Kilometrdan mile hisoblash ↗';
    input.closest('.tool-card').querySelector('label').textContent = 'Mile (mi)';
  }
  reverseDistance = !reverseDistance;
});
$('year').textContent = new Date().getFullYear();
updateDistance(); updateLiters(); updateFuel(); updateTotal();

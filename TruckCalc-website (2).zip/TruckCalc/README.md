# TruckCalc 🚛

TruckCalc — truck haydovchilari uchun mobilga mos, bepul kalkulyatorlar sayti.

## Imkoniyatlar
- Mile ↔ kilometr konvertori
- US gallon → litr konvertori
- Yoqilg‘i xarajatini taxminiy hisoblash
- Ikki yo‘l qismining umumiy masofasini hisoblash
- Telefon va kompyuter ekranlariga mos dizayn

## Ishga tushirish
1. `index.html`, `style.css` va `script.js` fayllarini bitta papkada saqlang.
2. `index.html` faylini brauzerda oching.
3. Internetga joylash uchun papkani Netlify Drop yoki GitHub Pages orqali yuklang.

## Muhim
Yoqilg‘i xarajati foydalanuvchi kiritgan MPG va gallon narxiga asoslangan taxminiy natijadir. Valyuta kurslari yoki real vaqt transport ma'lumotlari ulanmagan.

## Daromad haqida
Loyiha hozircha bepul MVP. Reklama yoki pullik xizmatlar qo‘shishdan oldin foydalanuvchilarni jalb qilish, maxfiylik siyosati, reklama platformasi qoidalari va to‘lov imkoniyatlarini tekshirish kerak. Daromad kafolatlanmaydi.
